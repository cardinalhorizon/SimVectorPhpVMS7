<?php

Route::group(['middleware' => ['api.auth']], function() {
    Route::post('/ingest', 'ApiController@ingestData');
    Route::get('/flights', 'FlightsController@search');
    Route::post('/bids', 'FlightsController@book');
    Route::delete('/bids', 'FlightsController@unbook');
});